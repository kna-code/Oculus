#include <osgParticle/Operator>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgParticleOperator,
                         /*new osgParticle::Operator*/NULL,
                         osgParticle::Operator,
                         "osg::Object osgParticle::Operator" )
{
}
