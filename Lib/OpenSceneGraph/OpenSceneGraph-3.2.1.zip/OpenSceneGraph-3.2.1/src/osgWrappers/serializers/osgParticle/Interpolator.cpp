#include <osgParticle/Interpolator>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgParticleInterpolator,
                         /*new osgParticle::Interpolator*/NULL,
                         osgParticle::Interpolator,
                         "osg::Object osgParticle::Interpolator" )
{
}
